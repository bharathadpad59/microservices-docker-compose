package com.service.currencyexchange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.sleuth.SamplerFunction;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CurrencyExchangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyExchangeApplication.class, args);
	}
	
	@Bean
	public SamplerFunction<?> deafultSampler() {
		return SamplerFunction.alwaysSample();
	}

}
