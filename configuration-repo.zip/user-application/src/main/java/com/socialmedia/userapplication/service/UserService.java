package com.socialmedia.userapplication.service;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.socialmedia.userapplication.entity.Users;
import com.socialmedia.userapplication.exception.ResourceNotFoundException;
import com.socialmedia.userapplication.repo.UserRespository;

@Service
public class UserService {

	@Autowired
	UserRespository userRespository;

	@Autowired
	MessageSource messageSource;

	public List<Users> getusers(Locale locale) {
		List<Users> user = userRespository.findAll();
	//	if (Optional.ofNullable(user).isPresent() && !Optional.ofNullable(user).isEmpty()) {
		if (Optional.ofNullable(user).isPresent()) {
			return user;
		}
		throw new ResourceNotFoundException(messageSource.getMessage("user.not.preset", null, locale));

	}

	public Users getuserById(Integer id, Locale locale) {
		Optional<Users> user = userRespository.findById(id);
	//	if (user.isPresent() && !(user.isEmpty())) {
			if (user.isPresent()) {
			return user.get();
		}
		throw new ResourceNotFoundException(messageSource.getMessage("user.not.found", new Object[] { id }, locale));

	}

	public Users createUser(Users user, Locale locale) {
		Users userExists = userRespository.findByUserNameAndUserId(user.getUserName(), user.getUserId());
		if (!Optional.ofNullable(userExists).isPresent()) {
			return userRespository.save(user);
		}
		throw new ResourceNotFoundException(messageSource.getMessage("user.already.exists",
				new Object[] { user.getUserId(), user.getDeptName() }, locale));

	}

	public Users updateUser(Users user, Locale locale) {
		Users userExists = userRespository.findByUserNameAndUserId(user.getUserName(), user.getUserId());
		if (Optional.ofNullable(userExists).isPresent()) {
			return userRespository.save(user);
		}
		throw new ResourceNotFoundException(messageSource.getMessage("username.not.found",
				new Object[] { Optional.ofNullable(user).isPresent() ? user.getUserName() : null }, locale));
	}

	public void deleteUser(Integer userId, Locale locale) {
		Optional<Users> user = userRespository.findById(userId);
	//	if (Optional.ofNullable(user).isPresent() && !user.isEmpty()) {
				if (Optional.ofNullable(user).isPresent()) {
			userRespository.delete(user.get());
			return;
		}
		throw new ResourceNotFoundException(
				messageSource.getMessage("user.not.found", new Object[] { userId }, locale));
	}

}
