package com.socialmedia.userapplication.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RestApiException {
    Map<?,?> errorMessage;
    String message;
    String httpStatus;
    String status;
}
