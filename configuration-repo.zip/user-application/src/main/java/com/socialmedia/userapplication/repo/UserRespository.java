package com.socialmedia.userapplication.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.socialmedia.userapplication.entity.Users;

@Repository
public interface UserRespository extends JpaRepository<Users, Integer> {

	Users findByUserNameAndUserId(String userName, Integer userId);
	
	Users findByUserNameAndDeptName(String userName, String deptName);
}
