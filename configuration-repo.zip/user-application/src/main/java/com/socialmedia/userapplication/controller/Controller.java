package com.socialmedia.userapplication.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.socialmedia.userapplication.configuration.ConfigProperties;
import com.socialmedia.userapplication.entity.Posts;
import com.socialmedia.userapplication.entity.Users;
import com.socialmedia.userapplication.exception.ExistingResourceFoundException;
import com.socialmedia.userapplication.exception.ResourceNotFoundException;
import com.socialmedia.userapplication.repo.PostRepository;
import com.socialmedia.userapplication.service.UserService;

@RestController
public class Controller {

	@Autowired
	UserService userService;

	@Autowired
	PostRepository postRepository;

	@Autowired
	ConfigProperties configProperties;
	
	@Autowired
	MessageSource messageSource;

//	@GetMapping("/")
//	public String test() {
//		return "Hello world";
//	}

	@GetMapping("/users")
	public ResponseEntity<List<Users>> getAllUsers() {
		return new ResponseEntity<List<Users>>(userService.getusers(LocaleContextHolder.getLocale()), HttpStatus.OK);
	}

	@GetMapping("/users/{id}")
	public ResponseEntity<EntityModel<Users>> getUser(@PathVariable @NotNull Integer id)
			throws ResourceNotFoundException {
		EntityModel<Users> model = EntityModel.of(userService.getuserById(id, LocaleContextHolder.getLocale()));
		model.add(linkTo(methodOn(Controller.class).getAllUsers()).withRel("all-users"));
		return new ResponseEntity<EntityModel<Users>>(model, HttpStatus.OK);
	}

	@PostMapping("/users")
	public ResponseEntity<Users> postUser(@RequestBody @Valid Users user) {
		return new ResponseEntity<Users>(userService.createUser(user, LocaleContextHolder.getLocale()),
				HttpStatus.CREATED);
	}

	@PutMapping("/update/users")
	public ResponseEntity<Users> updateUser(@RequestBody @Valid Users user) {
		return new ResponseEntity<Users>(userService.updateUser(user, LocaleContextHolder.getLocale()),
				HttpStatus.ACCEPTED);
	}

	@DeleteMapping("/delete/users/{id}")
	public ResponseEntity<Users> deleteUser(@PathVariable @NotNull Integer id) {
		userService.deleteUser(id, LocaleContextHolder.getLocale());
		return new ResponseEntity<Users>(HttpStatus.ACCEPTED);
	}

	@GetMapping("/users/{id}/posts")
	public ResponseEntity<List<Posts>> getAllPostOfUser(@PathVariable @NotNull Integer id) {
		Users user = userService.getuserById(id, LocaleContextHolder.getLocale());
			return new ResponseEntity<List<Posts>>(user.getPost(), HttpStatus.OK);
		}

	@PostMapping("/users/{id}/posts")
	public ResponseEntity<Posts> putPostForUser(@RequestBody @Valid Posts post, @PathVariable Integer id) {
		Users user = userService.getuserById(id, LocaleContextHolder.getLocale());
		boolean isPostExisteduser = user.getPost().stream()
				.anyMatch(userr -> userr.getPostName().equalsIgnoreCase(post.getPostName()));
		if (isPostExisteduser) {
			throw new ExistingResourceFoundException(
					"Posts with name: " + post.getPostName() + " Already Existed with Uer Name: " + user.getUserName());
		}
		post.setUser(user);
		Posts resultSet = postRepository.save(post);
		return new ResponseEntity<>(resultSet, HttpStatus.CREATED);
	}

	@GetMapping("/testCofigServer")
	public String testCloudConfigServer() {
		return "Hi This is the Username: " + configProperties.getUsername() + "& Password: "
				+ configProperties.getPassword() + ""
				+ " Received from Centralized configuration Server i.e Spring Cloud Config Server";
	}
}
