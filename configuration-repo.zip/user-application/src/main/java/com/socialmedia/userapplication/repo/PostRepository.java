package com.socialmedia.userapplication.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.socialmedia.userapplication.entity.Posts;

public interface PostRepository extends JpaRepository<Posts, Integer> {

	Posts findByPostName(String postName);
}
