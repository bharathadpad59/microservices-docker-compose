package com.socialmedia.userapplication.exception;

public class ExistingResourceFoundException extends  RuntimeException{

	private static final long serialVersionUID = 1L;

	public ExistingResourceFoundException(String message) {
        super(message);
    }
}