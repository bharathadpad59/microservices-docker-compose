//package com.socialmedia.userapplication.controller;
//
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.socialmedia.userapplication.pojo.PersonV1;
//import com.socialmedia.userapplication.pojo.PersonV2;
//
//@RestController
//public class VersionController {
//
//	// URI VERSIONING
//
//	@GetMapping("/v1/personInfo")
//	public PersonV1 getPersonInfo() {
//		return new PersonV1("Johnny lever");
//	}
//
//	@GetMapping("/v2/personInfo")
//	public PersonV2 getPersonFullInfo() {
//		return new PersonV2("Johnny", " lever");
//	}
//
//	// REQUEST PARAM VERSIONING
//
//	@GetMapping(value = "/personInfo", params = "version=v1")
//	public PersonV1 getPersonInfoParamsV1() {
//		return new PersonV1("Johnny lever");
//	}
//
//	@GetMapping(value = "/personInfo", params = "version=v2")
//	public PersonV2 getPersonInfoParamsV2() {
//		return new PersonV2("Johnny", " lever");
//	}
//
//	// HEADERS PARAM VERSIONING
//
//	@GetMapping(value = "/personInfo", headers = "version=v1")
//	public PersonV1 getPersonInfoHeadersV1() {
//		return new PersonV1("Johnny lever");
//	}
//
//	@GetMapping(value = "/personInfo", headers = "version=v2")
//	public PersonV2 getPersonInfoHedaersV2() {
//		return new PersonV2("Johnny", " lever");
//	}
//
//	// CONTENT TYPE/ PRODUCER VERSIONING
//
//	@GetMapping(value = "/personInfo", produces = "application/v1+json")
//	public PersonV1 getPersonInfoContentTypeV1() {
//		return new PersonV1("Johnny lever");
//	}
//
//	@GetMapping(value = "/personInfo", produces = "application/v2+json")
//	public PersonV2 getPersonInfoContentTypeV2() {
//		return new PersonV2("Johnny", " lever");
//	}
//
//}
