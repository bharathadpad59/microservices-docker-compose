package com.socialmedia.userapplication.globalexception;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.socialmedia.userapplication.exception.ExistingResourceFoundException;
import com.socialmedia.userapplication.exception.ResourceNotFoundException;
import com.socialmedia.userapplication.exception.RestApiException;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(value = ResourceNotFoundException.class)
	public ResponseEntity<Object> resourceNotFoundException(ResourceNotFoundException ex) {
		return new ResponseEntity<>(
				new RestApiException(new HashMap<>(), ex.getMessage(), HttpStatus.BAD_REQUEST.toString(), "FAILURE"),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(value = ExistingResourceFoundException.class)
	public ResponseEntity<Object> existingResourceNotFoundException(ExistingResourceFoundException ex) {
		return new ResponseEntity<>(
				new RestApiException(new HashMap<>(), ex.getMessage(), HttpStatus.BAD_REQUEST.toString(), "FAILURE"),
				HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			org.springframework.http.HttpHeaders headers, HttpStatus status, WebRequest request) {
		Map<Object, Object> map = ex.getBindingResult().getAllErrors().stream()
				.collect(Collectors.toMap(k -> ((FieldError) k).getField(), v -> v.getDefaultMessage()));
		return new ResponseEntity<>(
				new RestApiException(map, ex.getMessage(), HttpStatus.BAD_REQUEST.toString(), "FAILURE"),
				HttpStatus.BAD_REQUEST);
	}

}
