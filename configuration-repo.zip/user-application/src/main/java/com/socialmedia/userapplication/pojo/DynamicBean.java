package com.socialmedia.userapplication.pojo;

import com.fasterxml.jackson.annotation.JsonFilter;

import lombok.AllArgsConstructor;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonFilter("DynamicFilter")
public class DynamicBean {

	String field1;
	String field2;
	String field3;
	String field4;
}
