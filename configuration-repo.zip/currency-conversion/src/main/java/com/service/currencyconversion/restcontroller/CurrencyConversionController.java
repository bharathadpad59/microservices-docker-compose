package com.service.currencyconversion.restcontroller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.service.currencyconversion.configuration.ConfigProperties;
import com.service.currencyconversion.entity.CurrencyConversion;
import com.service.currencyconversion.proxy.CurrencyExchangeProxy;

@RestController
public class CurrencyConversionController {
	Logger logger= LoggerFactory.getLogger(CurrencyConversion.class);
	@Autowired
	CurrencyExchangeProxy currencyExchangeProxy;
	@Autowired
	ConfigProperties configProperties;

	@GetMapping("currency-conversion-feign/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion calculaConversionFeign(@PathVariable String from, @PathVariable String to,
			@PathVariable BigDecimal quantity) {

		CurrencyConversion currencyConversionResult = currencyExchangeProxy.getCurrencyExchangeService(from, to);
		logger.info("====================>>>>>>>>>>>>>>>>>>"+currencyConversionResult);
		
		logger.info("configProperties===========>>>Currency-Conversion==============>>>>"+
				configProperties.getUsername()+" "+configProperties.getPassword());
		return new CurrencyConversion(currencyConversionResult.getId(), from, to,
				currencyConversionResult.getConversionMultiple(), quantity,
				currencyConversionResult.getConversionMultiple().multiply(quantity),
				currencyConversionResult.getEnvironment() + " Feign");
	}

	@GetMapping("currency-conversion/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion calculaConversion(@PathVariable String from, @PathVariable String to,
			@PathVariable BigDecimal quantity) {

		Map<String, String> uriVariables = new HashMap<>();
		uriVariables.put("from", from);
		uriVariables.put("to", to);
		ResponseEntity<CurrencyConversion> currencyConversion = new RestTemplate().getForEntity(
				"http://localhost:8082/currency-exchange/{from}/to/{to}", CurrencyConversion.class, uriVariables);
		CurrencyConversion currencyConversionResult = currencyConversion.getBody();
		return new CurrencyConversion(currencyConversionResult.getId(), from, to,
				currencyConversionResult.getConversionMultiple(), quantity,
				currencyConversionResult.getConversionMultiple().multiply(quantity),
				currencyConversionResult.getEnvironment() + " Feign");
	}
}
