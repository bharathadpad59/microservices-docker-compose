package com.api.springbootapigateway.configuration;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MappingConfiguration {

	@Bean
	public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
		return builder.routes().route("currency_conversion", r -> r.path("/currency-conversion/**")
				.filters(f -> f.addRequestHeader("apiHeader", "BharatHeaders").addRequestParameter("apiRequestParam",
						"BharatParams"))
				.uri("lb://currency-conversion"))
				.route("currency_exchange", r -> r.path("/currency-exchange/**").uri("lb://currency-exchange"))
				.route("currency_conversion_feign",
						r -> r.path("/currency-conversion-feign/**")
								.filters(f -> f.rewritePath("/foo/(?<segment>.*)", "/${segment}"))
								.uri("lb://currency-conversion"))
				.build();

	}

}
