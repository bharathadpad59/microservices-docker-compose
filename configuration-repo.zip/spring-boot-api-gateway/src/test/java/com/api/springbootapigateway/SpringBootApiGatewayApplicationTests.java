package com.api.springbootapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootApiGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
